"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-02"
-------------------------------------------------------
"""

#Import

from functions import slope

#Input 

x1 = int(input("x1 coord: "))
y1 = int(input("y1 coord: "))
x2 = int(input("x2 coord: "))
y2 = int(input("y2 coord: "))
slp = slope(x1,y1,x2,y2)
print(slp)