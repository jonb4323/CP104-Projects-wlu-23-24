"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-02"
-------------------------------------------------------
"""

#Import

from functions import time_split

#Input
 
initialSec = int(input("Enter the initial seconds: "))
print(time_split(initialSec))
