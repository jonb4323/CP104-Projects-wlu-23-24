"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-02"
-------------------------------------------------------
"""

#Import

from functions import total_change

#Input 

nickels = int(input("Enter a number of nickels: "))
dimes = int(input("Enter a number of dimes: "))
quarters = int(input("Enter a number of quarters: "))
loonies = int(input("Enter a number of loonies: "))
toonies = int(input("Enter a number of toonies: "))
total = total_change(nickels,dimes,quarters,loonies,toonies)
print(f"{total:.2f}")