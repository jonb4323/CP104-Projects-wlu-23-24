"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-25"
-------------------------------------------------------
"""
#Import

from functions import diameter

#Input

r = float(input("Enter a radius: "))
diam = diameter(r)
print(diam)