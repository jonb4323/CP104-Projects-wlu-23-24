"""
-------------------------------------------------------
[Lab 1, Task 4]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-12"
-------------------------------------------------------
"""

name = input("Please enter your name: ")
print("Pleased to meet you ")
print(name)