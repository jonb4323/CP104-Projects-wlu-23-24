"""
-------------------------------------------------------
[Lab 1, Task 6]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-12"
-------------------------------------------------------
"""

# Calculate total pay
salary = 2500.0
bonus = 1200.0
pay = salary + bonus
print('Your pay is', pay)