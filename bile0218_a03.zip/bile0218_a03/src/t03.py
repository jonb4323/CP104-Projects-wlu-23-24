"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""

from functions import extract_date

print(extract_date(19621025))
