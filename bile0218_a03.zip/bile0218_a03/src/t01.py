"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""

from functions import footage_to_acres

print(footage_to_acres(100000.0))