"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""

from functions import lawn_mow_time

print(lawn_mow_time(20.0,50.0,4.0))