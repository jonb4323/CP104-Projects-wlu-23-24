"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-30"
-------------------------------------------------------
"""

def calc_factorial(number):
    """
    -------------------------------------------------------
    Calculates and returns the factorial of number.
    Use: product = calc_factorial(number)
    -------------------------------------------------------
    Parameters:
        number - number to factorial (int > 0)
    Returns:
        product - number! (int)
    ------------------------------------------------------
    """
    product = 1
    for x in range(1,number+1,1):
        product *= x
    return product

def calories_treadmill(per_min, minutes):
    """
    -------------------------------------------------------
    Running on a treadmill burns a certain number of calories. 
    calories_treadmill prints a table of the number of calories 
    burned every five minutes given the number of calories 
    burned per minute (per_min) an the total number of minutes 
    run (minutes). Align the results and print with 1 decimal 
    accuracy for the calories burned as shown in the 
    example execution.
    Use: total = calories_treadmill(per_min, minutes)
    -------------------------------------------------------
    Parameters:
        per_min - number of cals per min (float > 0)
        minutes - numebr of minutes on the treadmill for (int > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    min = 5
    for x in range(1,minutes+5,1):
        total = min * per_min    
        if x % 5 == 0:
            print(f"{min:>2} {total:>6.1f}")
            min += 5
    return None

def arrow_up(rows):
    """
    -------------------------------------------------------
    arrow_up takes an integer parameter and prints a arrow 
    of # characters pointing up.
    Use: print = arrow_up(rows)
    -------------------------------------------------------
    Parameters:
        rows - # of rows (int > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    for x in range(1,rows+1,1):
        spaces = rows - x
        if x == 1:
            print(" " * spaces + '#')
        else:
            print(" " * spaces + '#' + " " * (2 * (x - 1) - 1) + "#")                  
    return None 

def multiplication_table(start_num, stop_num):
    """
    -------------------------------------------------------
    Prints a multiplication table for values from start_num to stop_num.
    Use: multiplication_table(start_num, stop_num)
    -------------------------------------------------------
    Parameters:
        start_num - the range start value (int)
        stop_num - the range stop value (int)
    Returns:
        None
    ------------------------------------------------------
    """
    for i in range(start_num, stop_num+1,1):
        print(f"{i:<3}|" , end="")
        for j in range(start_num, stop_num+1,1):
            product = i * j
            print(f"{product:>5}" , end="")
        print()
    return None

def range_addition(start, increment, count):
    """
    -------------------------------------------------------
    Uses a for loop to sum values from start by increment.
    Use: total = range_addition(start, increment, count)
    -------------------------------------------------------
    Parameters:
        start - the range start value (int)
        increment - the range increment (int)
        count - the number of values in the range (int)
    Returns:
        total - the sum of the range (int)
    ------------------------------------------------------
    """
    sum = 0
    for x in range(start,start+increment*count,increment):
        sum += x
    return sum