"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-30"
-------------------------------------------------------
"""
from functions import multiplication_table
multiplication_table(2,4)