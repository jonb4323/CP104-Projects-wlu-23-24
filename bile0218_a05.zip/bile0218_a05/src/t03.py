"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-30"
-------------------------------------------------------
"""
from functions import arrow_up
arrow_up(4)