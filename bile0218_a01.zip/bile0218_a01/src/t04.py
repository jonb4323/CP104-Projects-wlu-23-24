"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-20"
-------------------------------------------------------
"""

costOfDosa = float(input("Cost of 1 dosa: $"))
numOfDosa = int(input("Number of dosa: "))
total = costOfDosa * numOfDosa
print("Total cost of" , numOfDosa , "dosas: $" , total)