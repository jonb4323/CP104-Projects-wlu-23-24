"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-20"
-------------------------------------------------------
"""

age = int(input("What is your age? "))
band = input("What is your favourite band? ")

print("I am" , age , "years old and" , band , "is my favourite band.")