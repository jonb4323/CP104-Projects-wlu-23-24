"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-20"
-------------------------------------------------------
"""

principal = float(input("Principal: $"))
interest = float(input("Interest (%): "))
interest = interest / 100.00
numOfYears = int(input("Number of years: "))
compoundPerYear = int(input("Number of times interest compounded per year: "))

bal = principal * ((1 + (interest / compoundPerYear)) ** (compoundPerYear * numOfYears))
print("\nBalance: $" , bal)