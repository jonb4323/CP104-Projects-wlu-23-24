"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-20"
-------------------------------------------------------
"""

miles = float(input("Length in miles: "))
km = miles * 1.61
print("Length in km:" , km)
