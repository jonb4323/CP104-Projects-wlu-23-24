"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""

def magic_date(day, month, year):
    """
    -------------------------------------------------------
    Determines if a date is magic. A date is magic if the day
    times the month equals the year.
    Use: magic = magic_date(day, month, year)
    -------------------------------------------------------
    Parameters:
        day - numeric day (int > 0)
        month - numeric month (int > 0)
        year - numeric two-digit year (int > 0)
    Returns:
        magic - True if date is magic, False otherwise (boolean)
    -------------------------------------------------------
    """
    
    TRUE = False 
    
    if day * month == year:
       TRUE = True
    else:
       TRUE = False
    return TRUE
   
def closest(target, v1, v2):
    """
    -------------------------------------------------------
    Determines closest value of two values to a target value.
    Use: result = closest(target, v1, v2)
    -------------------------------------------------------
    Parameters:
        target - the target value (float)
        v1 - first comparison value (float)
        v2 - second comparison value (float)
    Returns:
        result - one of v1 or v2 that is closest to target,
          v1 is the value chosen if v1 and v2 are an equal
          distance from target (float)
    -------------------------------------------------------
    """
    V1 = v1
    if v1 > target:
        dif1 = v1 - target
    else:
        dif1 = target - v1
    if v2 > target:
        dif2 = v2 - target
    else:
        dif2 = target - v2
    if dif1 == dif2:
        V1 = v1 
    if dif1 > dif2:
        V1 = v2
    else:
        V1 = v1
    return V1

def roman_numeral(n):
    """
    -------------------------------------------------------
    Convert 1-10 to Roman numerals.
    Use: numeral = roman_numeral(n)
    -------------------------------------------------------
    Parameters:
        n - number to convert to Roman numerals (int)
    Returns:
        numeral - Roman numeral version of n, None if n is not
          between 1 and 10 inclusive. (str)
    -------------------------------------------------------
    """
    
    ONE = "I" 
    TWO = "II"
    THREE = "III"
    FOUR = "IV" 
    FIVE = "V" 
    SIX = "VI" 
    SEVEN = "VII" 
    EIGHT = "VIII"
    NINE = "IX" 
    TEN = "X"
    CURRENT = ""
    
    if n == 1:
        CURRENT = ONE
    elif n == 2:
        CURRENT = TWO
    elif n == 3:
        CURRENT = THREE
    elif n == 4:
        CURRENT = FOUR
    elif n == 5:
        CURRENT = FIVE
    elif n == 6:
        CURRENT = SIX
    elif n == 7:
        CURRENT = SEVEN
    elif n == 8:
        CURRENT = EIGHT
    elif n == 9:
        CURRENT = NINE
    else:
        CURRENT = TEN
    return CURRENT 

def pay_raise(status, years, salary):
    """
    -------------------------------------------------------
    Calculates pay raises for employees. Pay raises are based on:
    status: Full Time ('F)' or Part Time ('P')
    and years of service
    Raises are:
        5% for full time greater than or equal to 10 years service
        1.5% for full time less than 4 years service
        3% for part time greater than 10 years service
        1% for part time less than 4 years service
        2% for all others
    Use: new_salary = pay_raise(status, years, salary)
    -------------------------------------------------------
    Parameters:
        status - employment type (str - 'F' or 'P')
        years - number of years employed (int > 0)
        salary - current salary (float > 0)
    Returns:
        new_salary - employee's new salary (float).
    -------------------------------------------------------
    """
    
    PERCENT_FIVE = 0.05
    PERCENT_ONE_POINT_FIVE = 0.015
    PERCENT_TWO = 0.02
    PERCENT_THREE = 0.03
    PERCENT_ONE = 0.01
    NEW_SALARY = 0
    
    if status == 'F':
        if years >= 10:
            NEW_SALARY = salary + (salary * PERCENT_FIVE)
        elif years < 4: 
            NEW_SALARY = salary + (salary * PERCENT_ONE_POINT_FIVE)
        else:
            NEW_SALARY = salary + (salary * PERCENT_TWO)
    else:
        if years > 10:
            NEW_SALARY = salary + (salary * PERCENT_THREE)
        elif years < 4: 
            NEW_SALARY = salary + (salary * PERCENT_ONE)
        else:
            NEW_SALARY = salary + (salary * PERCENT_TWO)
    return NEW_SALARY
    
def ticket():
    """
    -------------------------------------------------------
    School play ticket price calculation.
    Asks user for their age, and if necessary, if they are
    a student at the school. Prices:
        Infant (age < 3): $0
        Senior (age >= 65): $4.00
        Student (10 <= age < 18): $3.00
            Student of this school: $1.00
        Adult (18 <= age < 65): $5.00
        Kid (3 <= age < 10): $2.00
    Use: price = ticket()
    -------------------------------------------------------
    Returns:
        price - the price of one ticket (float)
    -------------------------------------------------------
    """
    TEN = 10
    THREE = 3
    EIGHTEEN = 18
    SIXTYFIVE = 65
    
    age = int(input("Enter your age: "))
    COST = 0
    if age < THREE: 
        COST = 0
    elif age >= SIXTYFIVE:
        COST =  4
    elif TEN <= age < EIGHTEEN:
        COST = 3
        school = str(input("Are you in school ('Y' 'N'): "))
        if school == 'Y':
            COST = 1 
    elif EIGHTEEN <= age < SIXTYFIVE:
        COST = 5
    else:
        COST = 2 
    return COST