"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""

from functions import closest

target = float(input("Enter the target: "))
v1 = float(input("Enter the first value: "))
v2 = float(input("Enter the second target: "))
print(closest(target,v1,v2))