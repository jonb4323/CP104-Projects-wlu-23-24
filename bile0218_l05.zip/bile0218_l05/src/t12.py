"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-06"
-------------------------------------------------------
"""
from functions import pay_raise

status = str(input("Enter 'P' for part time and 'F' for full time: "))
years = int(input("Enter years of service: "))
salary = float(input("Enter the current salary: "))
new_salary = pay_raise(status,years,salary)
print(f"{new_salary:.2f}")