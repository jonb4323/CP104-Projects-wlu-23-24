"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-06"
-------------------------------------------------------
"""
from functions import roman_numeral

num = int(input("Enter a number: "))
numeral = roman_numeral(num)
print(numeral)