"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""

from functions import magic_date

day = int(input("Enter a numeric day: "))
month = int(input("Enter a numeric month: "))
year = int(input("Enter a numeric year: "))

magic = magic_date(day,month,year)
print(magic)