"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
from functions import get_weekday_name
print(get_weekday_name(7))