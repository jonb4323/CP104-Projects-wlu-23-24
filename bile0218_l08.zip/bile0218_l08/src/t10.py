"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-06"
-------------------------------------------------------
"""
from functions import min_search
print(min_search([94,96,-22,-79,-28,-26,-50,-79,24,-32]))