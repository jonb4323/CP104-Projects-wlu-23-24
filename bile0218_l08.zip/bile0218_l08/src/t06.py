"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-06"
-------------------------------------------------------
"""
from functions import list_stats
print(list_stats([10.5,9.3,-4.2,23.1]))