"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-06"
-------------------------------------------------------
"""
from functions import linear_search
print(linear_search([94,96,-22,-79,-28,-26,-50,71,24,-32],-22))