"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-06"
-------------------------------------------------------
"""
def total_wins():
    """
    -------------------------------------------------------
    Enter a series of strings with the enter or return key
    Use: Enter = total_wins()
    -------------------------------------------------------
    Parameters:
        None
    Returns:
        two numbers representing how many times the string "purple"
        appeared in the input as well as "gold"
    ------------------------------------------------------
    """
    winsPurple = 0
    winsGold = 0
    GOLD = "gold"
    PURPLE = "purple"
    while True:
        uInput = input("Enter the game results (purple, gold or press enter): ")
        if uInput == "":
            break
        if uInput == GOLD:
            winsGold += 1
        elif uInput == PURPLE:
            winsPurple += 1
    return winsPurple,winsGold

def detect_prime(number):
    """
    -------------------------------------------------------
    Determines if number is a prime number.
    Use: prime = detect_prime(number)
    -------------------------------------------------------
    Parameters:
        number - an integer (int > 1)
    Returns:
        prime - True if number is prime, False otherwise (bool)
    ------------------------------------------------------
    """
    isPrime = True  
    if number > 0:
        if number <= 1:
            isPrime = False 
        if number == 2:
            isPrime = True 
        if number % 2 == 0:
            isPrime = False 
        count = 3
        while count <= int(number**0.5):
            if number % count == 0:
                isPrime = False 
            count += 2  
    return isPrime

def interest_table(principal_amount, interest_rate, payment):
    """
    -------------------------------------------------------
    Prints a table of monthly interest and payments on a loan.
    Use: interest_table(principal_amount, interest_rate, payment)
    -------------------------------------------------------
    Parameters:
        principal_amount - original value of a loan (float > 0)
        interest_rate - yearly interest interest_rate as a % (float >= 0)
        payment - the monthly payment (float > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    month = 1
    mIR = (interest_rate/100.00)/12.0
    bal = principal_amount
    print(f"Principal: ${principal_amount:.2f}")
    print(f"Interest Rate: {interest_rate:.2f}%")
    print(f"Monthly Payment: ${payment:.2f}")
    print("----------------------------------")
    print("Month Interest   Payment   Balance")
    print("----------------------------------")
    while bal > 0:
        mIntrest = bal * mIR
        if bal <= payment:
            payment = bal
            bal = 0
        else:
            bal = bal - payment + mIntrest
        print(f"  {month}    {mIntrest:.2f}     {payment:.2f}    {bal:.2f}")
        month += 1
    return None 

def count_of_digits(number):
    """
    -------------------------------------------------------
    Counts the number of digits in an integer.
    Use: digits = count_of_digits(number)
    -------------------------------------------------------
    Parameters:
        number - an integer (int)
    Returns:
        digits - the number of digits in number (int)
    ------------------------------------------------------
    """
    digits = 0
    if number == 0:
        digits = 1 
    elif number < 0:
        number *= -1
    while number > 0:
        number //= 10
        digits += 1
    return digits
        
def factor_summation(number):
    """
    -------------------------------------------------------
    Determines the sum of factors of an integer not including
    the integer itself. An integer's factors are the whole numbers
    that the integer can be evenly divided by.
    Use: total = factor_summation(number)
    -------------------------------------------------------
    Parameters:
        number - a positive integer (int >= 1)
    Returns:
        total - the total of number's factors (int)
    ------------------------------------------------------
    """
    total = 0
    divisor = 1
    while divisor < number:
        if number % divisor == 0:
            total += divisor
        divisor += 1
    return total