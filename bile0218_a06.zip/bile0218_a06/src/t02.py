"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-06"
-------------------------------------------------------
"""
from functions import detect_prime
print(detect_prime(131))