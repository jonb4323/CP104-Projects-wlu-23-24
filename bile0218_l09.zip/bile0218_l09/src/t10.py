"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-07"
-------------------------------------------------------
"""
from functions import text_analyze
print(text_analyze('12345'))