"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-23"
-------------------------------------------------------
"""

from functions import colour_combine
print(colour_combine("green","red"))