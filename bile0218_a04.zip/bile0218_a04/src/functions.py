"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-23"
-------------------------------------------------------
"""

def day_name(day_num):
    """
    -------------------------------------------------------
    Returns the name of a day of the week given an integer day number.
    Day 1 is "Sunday", day 7 is "Saturday".
    Returns "Error" if the number is not valid.
    Use: day = day_name(day_num)
    -------------------------------------------------------
    Parameters:
        day_num - day number (1 <= int <= 7)
    Returns:
        day - name of a day of the week (str)
    ------------------------------------------------------
    """
    MONDAY = "Monday"
    TUESDAY = "Tuesday"
    WEDNESDAY = "Wednesday"
    THURSDAY = "Thursday"
    FRIDAY = "Friday"
    SATURDAY = "Saturday"
    SUNDAY = "Sunday"
    dayOfWeek = ""
    if day_num == 1: 
        dayOfTheWeek = SUNDAY
    elif day_num == 2: 
        dayOfTheWeek = MONDAY
    elif day_num == 3: 
        dayOfTheWeek = TUESDAY
    elif day_num == 4: 
        dayOfTheWeek = WEDNESDAY
    elif day_num == 5: 
        dayOfTheWeek = THURSDAY
    elif day_num == 6: 
        dayOfTheWeek = FRIDAY
    else: 
        dayOfTheWeek = SATURDAY
    return dayOfTheWeek
def pollution_ranking(air_quality_index):
    """
    -------------------------------------------------------
    Returns the pollution level given an AQI (Air Quality Index):
        "Good" - 0 to 50 AQI
        "Moderate" - 51 - 100 AQI
        "Unhealthy for Sensitive Groups" - 101 - 150 AQI
        "Unhealthy" - 151 - 200 AQI
        "Very Unhealthy" - 201 - 300 AQI
        "Hazardous" - 300+ AQI
    Returns "Error" if air_quality_index is negative.
    Use: pollution = pollution_ranking(air_quality_index)
    -------------------------------------------------------
    Parameters:
        air_quality_index - Air Quality Index (int)
    Returns:
        pollution - name of pollution level (str)
    ------------------------------------------------------
    """
    GOOD = "Good"
    MOD = "Moderate"
    UNSENS = "Unhealthy for Sensitive Groups"
    UNHE = "Unhealthy"
    VUNHE = "Very Unhealthy"
    HAZ = "Hazardous"
    final = ""
    if air_quality_index <= 0 and air_quality_index <= 50:
        final = GOOD
    elif air_quality_index >= 51 and air_quality_index <= 100:
        final = MOD
    elif air_quality_index >= 101 and air_quality_index <= 150:
        final = UNSENS
    elif air_quality_index >= 151 and air_quality_index <= 200:
        final = UNHE 
    elif air_quality_index >= 201 and air_quality_index <= 300:
        final = VUNHE
    else:
        final = HAZ
    return final

def largest_average(val1, val2, val3):
    """
    -------------------------------------------------------
    Returns the average of the two largest values of
    val1, val2, and val3.
    Use: average = largest_average(val1, val2, val3)
    -------------------------------------------------------
    Parameters:
        val1 - a number (float)
        val2 - a number (float)
        val3 - a number (float)
    Returns:
        average - the average of the two largest values of
            val1, val2, and val3 (float)
    ------------------------------------------------------
    """
    highest = 0
    second = 0
    if val1 >= val2 and val1 >= val3:
        highest = val1
        if val2 >= val3:
            second = val2
        else:
            second = val3
    elif val1 <= val2 and val2 >= val3:
        highest = val2 
        if val1 >= val3:
            second = val1
        else:
            second = val3
    else:
        highest = val3
        if val1 >= val2:
            second = val1
        else:
            second = val2
    avg = (highest + second) / 2 
    return avg

def colour_combine(rgb_colour1, rgb_colour2):
    """
    -------------------------------------------------------
    Determines the secondary rgb_colour from mixing two primary
    RGB (Red, Green, Blue) colours. The order of the colours
    is *not* significant.
    Returns "Error" if any of the rgb_colour parameter(s) are invalid.
        "red" + "blue": "fuchsia"
        "red" + "green": "yellow"
        "green" + "blue": "aqua"
        "red" + "red": "red"
        "blue" + "blue": "blue"
        "green" + "green": "green"
    Use: rgb_colour = colour_combine(rgb_colour1, rgb_colour2)
    -------------------------------------------------------
    Parameters:
        rgb_colour1 - a primary RGB rgb_colour (str)
        rgb_colour2 - a primary RGB rgb_colour (str)
    Returns:
        rgb_colour - a secondary RGB rgb_colour (str)
    -------------------------------------------------------
    """
    RED = "red"
    GREEN = "green"
    BLUE = "blue"
    FUCHSIA = "fuchsia"
    YELLOW = "yellow"
    AQUA = "aqua"
    second = ""
    if rgb_colour1 == "red" and rgb_colour2 == "red":
        second = RED
    elif rgb_colour1 == "green" and rgb_colour2 == "green":
        second = GREEN
    elif rgb_colour1 == "blue" and rgb_colour2 == "blue":
        second = BLUE
    elif rgb_colour1 == "red" and rgb_colour2 == "blue" or rgb_colour2 == "red" and rgb_colour1 == "blue":
        second = FUCHSIA
    elif rgb_colour1 == "red" and rgb_colour2 == "green" or rgb_colour2 == "red" and rgb_colour1 == "green":
        second = YELLOW
    elif rgb_colour1 == "green" and rgb_colour2 == "blue" or rgb_colour2 == "green" and rgb_colour1 == "blue":
        second = AQUA
    return second

def hoo_rah(number):
    """
    -------------------------------------------------------
    hoo_rah(number) takes an integer parameter and returns 
    one of the following strings:
    Use: solution = hoo_rah(number)
                    

    "Hoo" if number is evenly divisible by 2
    "Rah" if number is evenly divisible by 7
    "Hoo Rah" if number is evenly divisible by both 2 and 7
    "Zip" if number is none of the above
    -------------------------------------------------------
    Parameters:
        Takes in a number - (number)
    Returns:
        hoo_rah - (str)
    -------------------------------------------------------
    """
    solution = ""
    count = 0
    if number % 2 == 0:
        solution = "Hoo"
        count = 1
    if number % 7 == 0:
        solution = "Rah"
        count = 1
    if number % 2 == 0 and number % 7 == 0:
        solution = "Hoo Rah"
        count = 1
    if count == 0:
        solution = "Zip"
    return solution