"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""

DOB = int(input("Enter a date in the format YYYYMMDD: "))
day = DOB % 100
year = DOB // 10000 
month = DOB % 10000 // 100
print(f"""The reformatted date: {year}/{month}/{day}""")
          

