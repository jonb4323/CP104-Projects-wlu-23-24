"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""

length = float(input("Foundation length (m): "))
width = float(input("Foundation width (m): "))
height = float(input("Foundation height (m): "))
wallH = float(input("Wall height (m): "))
cOConcrete = float(input("Cost of concrete ($/m^3): "))
cOBrick = float(input("Cost of bricks ($/m^2): "))

ccNeeded = length * width * height
cOConcrete = cOConcrete * ccNeeded 
bNeeded = 2 * (length * wallH) + 2 * (width * wallH)
cOBrick = cOBrick * bNeeded
total = cOConcrete + cOBrick

print(f"\nConcrete needed for foundation (m^3): {ccNeeded:.2f}")
print(f"Cost of concrete: ${cOConcrete:.2f}")
print(f"Bricks needed for walls (m^2): {bNeeded:.2f}")
print(f"Cost of bricks: ${cOBrick:.2f}")
print(f"Total Cost: ${total:.2f}")
      
