"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""

ANNUAL_TAX = 18.50

sales = float(input("Enter the total sales: $"))
tax = (sales / 100) * ANNUAL_TAX
print("\nProjected Tax Report")
print("--------------------------")
print(f"Total sales:    $ {sales:>7.2f}")
print(f"Annual tax:     % {ANNUAL_TAX:<7.2f}")
print("--------------------------")
print(f"Tax             $ {tax:>7.2f}")
