"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""

integer = int(input("Enter a positive digit number: "))
num1 = integer // 10
num2 = integer % 10
final = num1 - num2 
print("The difference of the digits of" , integer , "is" , final)
