"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-30"
-------------------------------------------------------
"""

flyers = int(input("Number of flyers: "))
deliveryPeople = int(input("Number of delivery people: "))

perPerson = int(flyers / deliveryPeople)
leftOver = flyers % deliveryPeople

print("\nFlyers per delivery person:" , perPerson)
print("Flyers left over:" , leftOver)