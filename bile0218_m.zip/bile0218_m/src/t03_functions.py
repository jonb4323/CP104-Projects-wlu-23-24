"""
-------------------------------------------------------
Midterm B Task 3 Function Definitions
-------------------------------------------------------
Author: Jonathan Bilewicz
ID:     169070218
Email:  bile0218@mylaurier.ca
__updated__ = "2023-10-29"
-------------------------------------------------------
"""
BASE_COST = 125.00
EXTRA_SERVICE = 25.00
DISCOUNT = 0.1

def servicing():
    """
    -------------------------------------------------------
    Determines the cost of getting a home furnace tune up. The cost is made up of:
        base cost: $125.00
        cost per extra service: $25.00
        VIP discount 10% only if:
            more than 1 extra service purchased
            and purchaser is a VIP
    The function must ask the user for these inputs.
    Use: cost = servicing()
    -------------------------------------------------------
    Returns‌​‌​​​​‌​​‌‌‌‌​​‌‌‌​‌​​​‌​‌​:
        cost - cost of getting a home furnace tune up based upon the base cost,
            the number of extra services purchased, and VIP discount
            if applicable (float)
    -------------------------------------------------------
    """
    cost = 0
    extraService = int(input("Enter the number of extra service purchased: "))
    buyer = str(input("Are you a VIP (Y/N)?: "))
    cost = BASE_COST + (extraService * EXTRA_SERVICE)
    if extraService > 1 and buyer == "Y":
        vipDiscount = DISCOUNT * cost
    return cost
