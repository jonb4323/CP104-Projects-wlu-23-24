"""
-------------------------------------------------------
Midterm B Task 4 Testing
-------------------------------------------------------
Author: Jonathan Bilewicz
ID:     169070218
Email:  bile0218@mylaurier.ca
__updated__ = "2023-10-29"
-------------------------------------------------------
"""
from t04_functions import get_it


response = input("Enter a classification: ")
print(get_it(response))
