"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-07"
-------------------------------------------------------
"""

from functions import draw_rectangle

draw_rectangle(3,12,'#')
