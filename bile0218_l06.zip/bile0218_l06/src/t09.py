"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-18"
-------------------------------------------------------
"""

from functions import bottles_of_beer

bottles_of_beer(6)