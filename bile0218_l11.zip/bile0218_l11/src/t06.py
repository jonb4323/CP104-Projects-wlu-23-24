"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""
from functions import matrix_stats
print(matrix_stats([[2, 0, -1, 1], [10, 4, -5, 9], [-6, 3, 6, 0]]))