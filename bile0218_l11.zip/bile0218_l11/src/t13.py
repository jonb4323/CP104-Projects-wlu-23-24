"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""
from functions import matrix_scalar_multiply
matrix_scalar_multiply([[-6, -3, -7], [-4, 5, -10]], 5)