"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-22"
-------------------------------------------------------
"""
from functions import generate_matrix_num
print(generate_matrix_num(3, 4, -10, 10, "float"))