"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""
from functions import generate_matrix_char
print(generate_matrix_char(3,4))