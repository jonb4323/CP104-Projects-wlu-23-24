"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-22"
-------------------------------------------------------
"""

import random

def generate_matrix_num(rows, cols, low, high, value_type):
    """
    -------------------------------------------------------
    Generates a 2D list of numbers of the given type, 'float' or 'int'.
    (To generate random float number use random.uniform and to
    generate random integer number use random.randint)
    Use: matrix = generate_matrix_num(rows, cols, low, high, value_type)
    -------------------------------------------------------
    Parameters:
        rows - number of rows in the list (int > 0)
        cols - number of columns (int > 0)
        low - low value of range (float)
        high - high value of range (float > low)
        value_type - type of values in the list, 'float' or 'int' (str)
    Returns:
        matrix - a 2D list of random numbers (2D list of float/int)
    -------------------------------------------------------
    """
    arr = [[0]*cols for _ in range(rows)]
    for i in range(rows):
        for j in range(cols):
            if value_type == 'float':
                value = random.uniform(low, high)
            elif value_type == 'int':
                value = random.randint(low, high)
            arr[i][j] = value
    return arr

def generate_matrix_char(rows, cols):
    """
    -------------------------------------------------------
    Generates a 2D list of random lower case letter ('a' - 'z') values
    Use: matrix = generate_matrix_char(rows, cols)
    -------------------------------------------------------
    Parameters:
        rows - number of rows in the generated matrix (int > 0)
        cols - number of columns in the generated matrix (int > 0)
    Returns:
        matrix - a 2D list of random characters (2D list of str)
    -------------------------------------------------------
    """
    ALPH = 'abcdefghijklmnopqrstuvwxyz'
    
    arr = [[0]*cols for _ in range(rows)]
    for i in range(rows):
        for j in range(cols):
            rand = random.randint(0,25)
            arr[i][j] = ALPH[rand]
    return arr

def words_to_matrix(word_list):
    """
    -------------------------------------------------------
    Generates a 2D list of character values from the given
    list of words. All words must be the same length.
    Use: matrix = words_to_matrix(word_list)
    -------------------------------------------------------
    Parameters:
        word_list - a list containing the words to be placed in
            the matrix (list of string)
    Returns:
        matrix - a 2D list of characters of the given words
         in word_list (2D list of string).
    -------------------------------------------------------
    """
    arr = []
    for i in word_list:
        arr.append(list(i))
    return arr

def matrix_stats(matrix):
    """
    -------------------------------------------------------
    Returns statistics on a 2D list.
        Use: smallest, largest, total, average = matrix_stats(matrix)
    -------------------------------------------------------
    Parameters:
        matrix - a 2D list of numbers (2D list of float/int)
    Returns:
        smallest - the smallest number in matrix (float/int)
        largest - the largest number in matrix (float/int)
        total - the total of the numbers in matrix (float/int)
        average - the average of numbers in matrix (float/int)
    -------------------------------------------------------
    """
    temp = []
    total = 0
    avg = 0.0
    count = 0
    for i in range(len(matrix)):
        try:
            value = len(matrix[i])
        except:
            count = 1
            temp = matrix.copy()
            break 
        for j in range(len(matrix[i])):
            if count != 1:
                total += matrix[i][j]
                temp.append(matrix[i][j])
                avg += 1     
    if count == 1:
        for j in range(len(temp)):
            total += temp[j]
            avg += 1
    temp.sort()
    smallest = temp[0]
    largest = temp[-1]
    avg = total / avg
    return smallest,largest,total,avg

def matrix_scalar_multiply(matrix, num):
    """
    -------------------------------------------------------
    Update matrix by multiplying each element of matrix by num.
    Use: matrix_scalar_multiply(matrix, num)
    -------------------------------------------------------
    Parameters:
        matrix - the matrix to multiply (2D list of int/float)
        num - the number to multiply by (int/float)
    Returns:
        None
    ------------------------------------------------------
    """
    for i in range(len(matrix)):
        for j in range(len(matrix[i])):
            value = matrix[i][j] * num
            matrix[i][j] = value
    return None