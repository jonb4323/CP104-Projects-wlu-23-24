"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""
strings = ["cat", "dog", "big"]
from functions import words_to_matrix
print(words_to_matrix(strings))