"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-13"
-------------------------------------------------------
"""

height = float(input("Enter your height (m): "))
kg = float(input("Enter your weight (kg): "))
BMIUpperLimit = int(input("Enter your upper limit BMI (23 if you are from South East Asia and Southern China, 25 for everyone else): "))

BMI = (kg / height ** 2)
BMIPrime = BMI / BMIUpperLimit

BMI = round(BMI,2)
BMIPrime = round(BMIPrime,2)


print("Body Mass Index (kg/m^2) = " , BMI)
print("BMI Prime = " , BMIPrime)