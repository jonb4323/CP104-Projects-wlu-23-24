"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-12"
-------------------------------------------------------
"""

LARGE_DOG = 75
SMALL_DOG = 50

largeDogs = int(input("Enter the number of large dogs groomed: "))
smallDogs = int(input("Enter the number of small dogs groomed: "))
                
total = (largeDogs * LARGE_DOG) + (smallDogs * SMALL_DOG)
print("The total revenue is: " , total)