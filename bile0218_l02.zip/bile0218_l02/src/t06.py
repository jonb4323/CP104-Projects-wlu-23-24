"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-12"
-------------------------------------------------------
"""

pAmt = float(input("Enter a principal amount: "))
numYears = int(input("Enter the number of years: "))
yInt = float(input("Enter the annual interest rate: ")) / 100
mInt = float(yInt / 12.0)
numMonths = numYears * 12

mortgage = pAmt * ((mInt * (1 + mInt) ** numMonths) / ((1 + mInt) ** numMonths - 1))

print("Your monthly mortgage is:", mortgage)