"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-13"
-------------------------------------------------------
"""

numOfFlyers = int(input("Enter the number of flyers: "))
numOfVol = int(input("Enter the number of volunteers: "))

fPV = int(numOfFlyers // numOfVol)
lOF = int(numOfFlyers % numOfVol)

print("Flyers per volunteer: " , fPV)
print("Flyers leftover are: " , lOF)