"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
from functions import file_copy
with open('numbers.txt', 'r') as source_file:
    with open('customers.txt', 'w') as target_file:
        file_copy(source_file, target_file)