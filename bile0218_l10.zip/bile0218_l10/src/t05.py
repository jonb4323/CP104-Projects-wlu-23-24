"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
from functions import customer_append
data =['35612', 'David', 'Brown', 237.56, '2008-10-10']
print('Data: ' , data)
file_handle = open('customers.txt','a')
customer_append(file_handle,data)
file_handle.close()

