"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
from functions import count_frequency_word
with open('words.txt','r') as file_handle:
    print(count_frequency_word(file_handle,'Exercise'))