"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-31"
-------------------------------------------------------
"""
from functions import power_of_two
print(power_of_two(248))