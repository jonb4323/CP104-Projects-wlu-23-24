"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-10-30"
-------------------------------------------------------
"""

from random import randint

def hi_lo_game(high):
    """
    -------------------------------------------------------
    Plays a random higher-lower guessing game.
    Use: count = hi_lo_game(high)
    -------------------------------------------------------
    Parameters:
        high - maximum random value (int > 1)
    Returns:
        count - the number of guesses the user made (int)
    -------------------------------------------------------
    """
    number = randint(1,high)
    ans1 = int(input("Guess: "))
    guesses = 1
    ans = ans1
    while ans != number:
        if ans > number:
            print("Too high, try again.")
        if ans < number:
            print("Too low, try again.")
        guesses += 1
        ans = int(input("Guess: "))
    print("Congratulations - good guess!")
    print(f"You made {guesses} guesses.")
    return guesses

def power_of_two(target):
    """
    -------------------------------------------------------
    Determines the nearest power of 2 greater than or equal to
    a given target.
    Use: power = power_of_two(target)
    -------------------------------------------------------
    Parameters:
        target - value to find nearest power of 2 (int >= 0)
    Returns:
        power - first power of 2 >= target (int)
    -------------------------------------------------------
    """
    power = 1 
    while power < target:
        power*= 2 
    return power

def sum_squares(target):
    """
    -------------------------------------------------------
    Determines the sum of squares closest to, and greater than or
    equal to, a target value.
    Use: final = sum_squares(target)
    -------------------------------------------------------
    Parameters:
        target - target value (int >= 0)
    Returns:
        final - the final sum of squares >= target (int)
    -------------------------------------------------------
    """
    check = 0
    n = 1
    while check <= target:
        check += n * n
        n+=1
    return check

def meal_costs():
    """
    -------------------------------------------------------
    Asks a user the costs of breakfast, lunch, and supper for each
    day the user was away. Assumes there is at least one day, and
    after entering data for each day asks the user whether they want
    to enter data for another day. Calculates total costs for meals.
    Use: b_total, l_total, s_total, a_total = meal_costs()
    -------------------------------------------------------
    Returns:
        b_total - total breakfasts cost (float)
        l_total - total lunches cost (float)
        s_total - total suppers cost (float)
        a_total - all meals cost (float)
    ------------------------------------------------------
    """
    days = 1
    anotherDay = True
    b_total = 0
    l_total = 0
    s_total = 0
    a_total = 0
    a_t = 0
    while anotherDay != False:
        b_t = float(input("Enter the cost of Breakfast?: "))
        b_total += b_t
        l_t = float(input("Enter the cost of Lunch?: "))
        l_total += l_t
        s_t = float(input("Enter the cost of Dinner?: "))
        s_total += s_t
        a_t = b_t + l_t + s_t
        a_total = b_total + l_total + s_total
        print(f"Your total for the day was ${a_t:.2f}")
        check = str(input("Were you away another day (Y/N)? "))
        if check != "Y":
            anotherDay = False
    return b_total,l_total,s_total,a_total
def employee_payroll():
    """
    -------------------------------------------------------
    Calculates and returns the weekly employee payroll for all employees
    in an organization. For each employee, ask the user for the employee ID
    number, the hourly wage rate, and the number of hours worked during a week.
    An employee number of zero indicates the end of user input.
    Each employee is paid 1.5 times their regular hourly rate for all hours
    over 40. A tax amount of 3.625 percent of gross salary is deducted.
    Use: total, average = employee_payroll()
    -------------------------------------------------------
    Returns:
        total - total net employee wages (i.e. after taxes) (float)
        average - average employee net wages (float)
    ------------------------------------------------------
    """
    TAX_RATE = 0.03625
    OVERTIME = 1.5
    OVERTIME_RATE = 40
    total = 0 
    average = 0
    id = 1
    numOfPeople = 0
    while id != 0:
        id = int(input("Employee ID: "))
        if id == 0:
            break
        numOfPeople += 1
        rate = float(input("Hourly wage rate: "))
        hWorked = float(input("Hours worked: "))
        if hWorked <= 40:
            netPay = rate * hWorked
        else:
            netPay = (rate * OVERTIME_RATE) + (rate * OVERTIME * (hWorked - OVERTIME_RATE))
        netPay = netPay - (netPay * TAX_RATE)
        print(f"Net payment for employee {id}: ${netPay:.2f}")
        print()
        total += netPay
        average = (total / numOfPeople)
    print()
    return (total,average)
    
    
    
    
    
    
    