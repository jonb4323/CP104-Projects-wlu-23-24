"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-14"
-------------------------------------------------------
"""

integer = 654321
decimal = 654.32
phrase = "Hello World"

print(f"{integer:d}")
print(f"{integer:f}")
#print(f"{integer:s}")
#print(f"{decimal:d}")
print(f"{decimal:f}")
#print(f"{decimal:s}")
#print(f"{phrase:d}")
#print(f"{phrase:f}")
print(f"{phrase:s}")

