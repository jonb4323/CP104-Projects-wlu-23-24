"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-13"
-------------------------------------------------------
"""

num = float(input("Enter a number: "))
discount = float(input("Enter a percent: "))
newPrice = num * (discount / 100)
print(f"A {discount:.1f} percent discount on {num} is {newPrice:.1f}")
