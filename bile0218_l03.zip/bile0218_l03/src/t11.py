"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-13"
-------------------------------------------------------
"""

location1 = "left"
location2 = "middle" 
location3 = "right"

print(f"{location1:-<20}")
print(f"{location2:-^20}")
print(f"{location3:->20}")