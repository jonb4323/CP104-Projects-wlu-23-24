"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-09-13"
-------------------------------------------------------
"""

breakfast = float(input("Enter cost of breakfast: "))
lunch = float(input("Enter cost of lunch: "))
supper = float(input("Enter cost of supper: "))
final = breakfast + lunch + supper 
print("Meal        Cost")
print(f"Breakfast   ${breakfast:>6.2f}")
print(f"lunch       ${lunch:>6.2f}")
print(f"supper      ${supper:>6.2f}")
print(f"Total       ${final:>6.2f}")
