"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-15"
-------------------------------------------------------
"""
from functions import common_end
print(common_end('ing','jumping'))