"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
from functions import add_spaces
print(add_spaces('StopAndSmellTheRoses.'))
