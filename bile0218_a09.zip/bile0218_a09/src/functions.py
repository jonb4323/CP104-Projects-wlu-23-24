"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
def file_top(file_handle, count):
    """
    -------------------------------------------------------
    Prints first count lines of file_handle. Line numbering starts at 0.
    If length of file is shorter than count, stops printing after
    last line of file.
    Use: file_top(file_handle, count)
    -------------------------------------------------------
    Parameters:
        file_handle - file to process (file handle - open for reading)
        count - number of lines to print (int > 0)
    Returns:
        None
    -------------------------------------------------------
    """
    counter = 0
    while counter < count:
        str = file_handle.readline()
        if not str:
            break
        line = str.strip()
        print(line)
        count += 1
    return None

def read_integers(file_handle):
    """
    -------------------------------------------------------
    Extracts positive integers from a file into a list of integers.
    Numbers are comma-delimited. Non-numeric tokens are ignored.
    Use: number_list = read_integers(file_handle)
    -------------------------------------------------------
    Parameters:
        file_handle - file to process (file handle - open for reading)
    Returns:
        number_list - a list of integers from file_handle (list of int)
    -------------------------------------------------------
    """
    list = []
    for line in file_handle:
        numbers = line.split(',')
        for i in numbers:
            try:
                num = int(i.strip())
                if num > 0:
                    list.append(num)
            except ValueError:
                pass
    return list 

def file_statistics(file_handle):
    """
    -------------------------------------------------------
    Evaluates the contents of a file by counting upper-case letters,
    lower-case letters, digits, white-spaces (including end-of-line
    characters), and remaining characters.
    Use: ucount, lcount, dcount, wcount, rcount = file_statistics(file_handle)
    -------------------------------------------------------
    Parameters:
        file_handle - file to process (file handle - open for reading)
    Returns:
        ucount - The number of upper-case letters in the file (int)
        lcount - The number of lower-case letters in the file (int)
        dcount - The number of digits in the file (int)
        wcount - The number of white-space characters in the file (int)
        rcount - The number of remaining characters in the file (int)
    -------------------------------------------------------
    """
    ucount = 0
    lcount = 0 
    dcount = 0
    wcount = 0
    rcount = 0
    for line in file_handle:
        for i in line:
            if i.isupper():
                ucount+=1
            elif i.islower():
                lcount+=1
            elif i.isdigit():
                dcount+=1
            elif i.isspace():
                wcount+=1
            else:
                rcount +=1
    return ucount,lcount,dcount,wcount,rcount
    
def line_numbering(fh_read, fh_write):
    """
    -------------------------------------------------------
    Adds line numbers to a file. Contents of fh_write contain contents
    of fh_read where every line has line numbers added to the beginning
    of the line in the format [number]. Line numbering starts at 0.
    Put a single space after the line number.
    Use: line_numbering(fh_read, fh_write)
    -------------------------------------------------------
    Parameters:
        fh_read - file to read (file - open for reading)
        fh_write - file to write (file - open for writing)
    Returns:
        None
    -------------------------------------------------------
    """
    count = 0
    for line in fh_read:
        str = line.strip()
        fh_write.write(f"[{count}] {str}\n")
        count+=1
    return None

def student_stats(file_handle):
    """
    -------------------------------------------------------
    Get information from a file of file_handle and grades.
    Use: l_id, h_id, avg = student_stats(file_handle)
    -------------------------------------------------------
    Parameters:
        file_handle - student information file in the format
            surname,forename,id,mark (file - open for reading)
    Returns:
        l_id - the id of the student with the lowest mark (str)
        h_id - the id of the student with the highest mark (str)
        avg - the average mark (float)
    -------------------------------------------------------
    """
    mark = []
    studentID =[]
    for line in file_handle:
        str = line.strip().split(',')
        studentID.append(str[2])
        mark.append(int(str[3]))
    temp = mark.index(min(mark))
    l_id = studentID[temp] 
    temp = mark.index(max(mark))
    h_id = studentID[temp]
    avg = sum(mark) / len(mark)
    return l_id,h_id,avg