"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
from functions import file_top
with open('students.txt','r') as file_handle:
    file_top(file_handle,5)
    