"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
from functions import file_statistics
with open('fileStats.txt','r') as file_handle:
    print(file_statistics(file_handle))