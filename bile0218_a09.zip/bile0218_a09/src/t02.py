"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
from functions import read_integers
with open('numbers.txt','r') as file_handle:
    print(read_integers(file_handle))