"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:    Jonathan Bilewicz
ID:    169070218
Email:    bile0218@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""
from functions import line_numbering
with open('numbers.txt', 'r') as source_file:
    with open('customers.txt', 'w') as target_file:
        line_numbering(source_file, target_file)